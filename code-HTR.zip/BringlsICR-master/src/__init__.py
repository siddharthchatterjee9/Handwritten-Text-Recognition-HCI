app.static_folder = 'static'
